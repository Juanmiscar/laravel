<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titulo <?php echo $__env->yieldContent('titulo'); ?></title>
</head>
<body>
    <?php $__env->startSection('header'); ?>
    CABECERA DE LA WEB MASTER
    <?php echo $__env->yieldSection(); ?>
    <div class='container'>
        
    </div>
    <?php $__env->startSection('footer'); ?>
    PIE DE LA PAGINA
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Jaumo\ProyectoBotiga\resources\views/administrador/master.blade.php ENDPATH**/ ?>