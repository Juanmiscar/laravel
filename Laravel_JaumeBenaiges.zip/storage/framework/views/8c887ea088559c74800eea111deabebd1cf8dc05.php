
<?php $__env->startSection('titulo', 'Laravel'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
    <h2> Hola </h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1> Pagina principal </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jaumo\ProyectoBotiga\resources\views/administrador/paginaGenerica.blade.php ENDPATH**/ ?>