<li>Gerstionar Productos</li>
<li>Gestionar Categorias </li><?php /**PATH C:\Users\Jaumo\ProyectoBotiga\resources\views/administrador/principal.blade.php ENDPATH**/ ?>