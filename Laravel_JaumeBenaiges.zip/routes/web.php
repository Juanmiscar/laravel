<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdministradorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//ADMINISTRACION

Route::get('/admin', [AdministradorController::class, 'inicio_sesion'])->name('inicio_sesion');

Route::post('/verificar', [AdministradorController::class, 'verificar'])->name('verificar');

Route::get('/inicioAdmin', function(){
    return view('administrador.inicioAdmin');
});

//Links
Route::get('/productosAdmin', [AdministradorController::class, 'productosAdmin'])->name('productosAdmin');
Route::get('/categoriasAdmin', [AdministradorController::class, 'categoriasAdmin'])->name('categoriasAdmin');
Route::get('/pedidosAdmin', [AdministradorController::class, 'pedidosAdmin'])->name('pedidosAdmin');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
